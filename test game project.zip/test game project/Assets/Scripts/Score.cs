﻿using UnityEngine;
using UnityEngine.UI;
public class Score : MonoBehaviour {

	public Transform player;
	public Text scoretxt;
	public Collision collitionInfo;
	// Update is called once per frame
	void Update () {

		if (player.position.y >= 1) {
			scoretxt.text = player.position.z.ToString ("0");
		}
		else{

		}
	}
}
