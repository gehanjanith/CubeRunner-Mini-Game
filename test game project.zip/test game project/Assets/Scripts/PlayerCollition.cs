﻿using UnityEngine;

public class PlayerCollition : MonoBehaviour {

	public PlayerMovement movement;

	void OnCollisionEnter(Collision collitionInfo){

		if (collitionInfo.collider.tag == "Obstracles") {
			movement.enabled = false;
		}
	
	}
}
